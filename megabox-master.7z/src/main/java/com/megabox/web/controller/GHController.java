package com.megabox.web.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class GHController {

}
