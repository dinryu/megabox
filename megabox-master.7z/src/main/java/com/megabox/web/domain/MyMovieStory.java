package com.megabox.web.domain;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component @Data
public class MyMovieStory {
	private String id,movieTitle,movieCheck;

}
