package com.megabox.web.command;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component @Data
public class ResultMap {

}
